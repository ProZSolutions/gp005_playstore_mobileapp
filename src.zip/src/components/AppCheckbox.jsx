// src/components/AppCheckbox.jsx
import React from 'react';
import { StyleSheet, TouchableOpacity } from 'react-native';
import { Checkbox, Text, useTheme } from 'react-native-paper';

/**
 * AppCheckbox
 * Props:
 *  - label         (string) required — text shown next to checkbox
 *  - checked       (bool)   required — current checked state
 *  - onToggle      (func)   required — called on press
 *  - disabled      (bool)   grays out and blocks press
 *  - indeterminate (bool)   shows dash/indeterminate state
 */
export function AppCheckbox({
  label,
  checked,
  onToggle,
  disabled = false,
  indeterminate = false,
}) {
  const theme = useTheme();

  return (
    <TouchableOpacity
      style={styles.row}
      onPress={onToggle}
      disabled={disabled}
      activeOpacity={0.7}
    >
      <Checkbox
        status={indeterminate ? 'indeterminate' : checked ? 'checked' : 'unchecked'}
        onPress={onToggle}
        disabled={disabled}
        color={theme.colors.primary}
      />
      <Text
        style={[
          styles.label,
          {
            color: disabled
              ? theme.colors.onSurfaceDisabled
              : theme.colors.onSurface,
          },
        ]}
      >
        {label}
      </Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 4,
  },
  label: {
    marginLeft: 8,
    fontSize: 16,
  },
});