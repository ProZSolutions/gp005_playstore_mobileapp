// src/screens/DemoScreen.jsx
import React, { useState } from 'react';
import { ScrollView, StyleSheet, View } from 'react-native';
import {
  Appbar,
  Divider,
  Text,
  TextInput,
  useTheme,
  Switch,
  List,
} from 'react-native-paper';
import { SafeAreaView } from 'react-native-safe-area-context';

import {
  AppButton,
  AppInput,
  AppCheckbox,
  AppDatePicker,
  AppListItem,
  AppCard,
  AppChipGroup,
  AppRadioGroup,
  AppSelect,
  AppModal,
  AppSnackbar,
  AppDivider,
  AppAvatar,
  AppBadge,
} from '../components';

// ── Helper: Section heading ────────────────────────────────────
function SectionHeader({ label }) {
  const theme = useTheme();
  return (
    <Text
      variant="titleMedium"
      style={{ color: theme.colors.primary, marginBottom: 10, fontWeight: '700' }}
    >
      {label}
    </Text>
  );
}

// ── Main Screen ───────────────────────────────────────────────
export function DemoScreen({ route }) {
  const { toggleTheme, isDark } = route.params;
  const theme = useTheme();

  // Text inputs
  const [name, setName]       = useState('');
  const [email, setEmail]     = useState('');
  const [password, setPassword] = useState('');
  const [nameError, setNameError] = useState('');

  // Checkboxes
  const [checkA, setCheckA] = useState(false);
  const [checkB, setCheckB] = useState(true);

  // Date picker
  const [date, setDate] = useState(undefined);

  // Chips
  const [selectedChips, setSelectedChips] = useState([]);

  // Radio
  const [radio, setRadio] = useState('option1');

  // Select
  const [fruit, setFruit] = useState(undefined);

  // Modal & Snackbar
  const [modalVisible, setModalVisible] = useState(false);
  const [snackVisible, setSnackVisible] = useState(false);

  // ── Data ────────────────────────────────────────────────────
  const chips = [
    { id: 'react',  label: 'React Native',  icon: 'react' },
    { id: 'js',     label: 'JavaScript',    icon: 'language-javascript' },
    { id: 'paper',  label: 'Paper UI',      icon: 'palette' },
    { id: 'nav',    label: 'Navigation',    icon: 'navigation' },
  ];

  const radioOptions = [
    { label: 'Option A', value: 'option1' },
    { label: 'Option B', value: 'option2' },
    { label: 'Disabled', value: 'option3', disabled: true },
  ];

  const fruitOptions = [
    { label: 'Apple',  value: 'apple' },
    { label: 'Banana', value: 'banana' },
    { label: 'Cherry', value: 'cherry' },
    { label: 'Durian', value: 'durian' },
  ];

  const listItems = [
    { id: 1, title: 'Inbox',   icon: 'inbox',           count: 5 },
    { id: 2, title: 'Starred', icon: 'star-outline',    count: 2 },
    { id: 3, title: 'Sent',    icon: 'send-outline',    count: 0 },
    { id: 4, title: 'Trash',   icon: 'trash-can-outline', count: 12 },
  ];

  // ── Handlers ────────────────────────────────────────────────
  const toggleChip = (id) =>
    setSelectedChips((prev) =>
      prev.includes(id) ? prev.filter((c) => c !== id) : [...prev, id]
    );

  const handleValidate = () => {
    if (!name.trim()) {
      setNameError('Name is required');
    } else {
      setNameError('');
      setSnackVisible(true);
    }
  };

  // ── Render ──────────────────────────────────────────────────
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: theme.colors.background }}>
      {/* Header */}
      <Appbar.Header elevated>
        <Appbar.Content title="Component Library" />
        <Text variant="labelMedium" style={{ marginRight: 8, color: theme.colors.onSurface }}>
          Dark
        </Text>
        <Switch value={isDark} onValueChange={toggleTheme} style={{ marginRight: 8 }} />
      </Appbar.Header>

      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>

        {/* ── AVATARS ─────────────────────────────────────── */}
        <SectionHeader label="Avatars" />
        <View style={styles.row}>
          <AppAvatar type="text" label="JD" size={52} />
          <AppAvatar type="icon" icon="account" size={52} />
          <AppAvatar type="image" source="https://i.pravatar.cc/100" size={52} />
          <View style={{ position: 'relative' }}>
            <AppAvatar type="icon" icon="bell" size={52} />
            <View style={styles.badgeWrap}>
              <AppBadge count={7} />
            </View>
          </View>
        </View>

        <AppDivider label="INPUTS" />

        {/* ── TEXT INPUTS ─────────────────────────────────── */}
        <SectionHeader label="Text Inputs" />
        <AppInput
          label="Full Name"
          value={name}
          onChangeText={setName}
          error={nameError}
          left={<TextInput.Icon icon="account" />}
        />
        <AppInput
          label="Email Address"
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
          autoCapitalize="none"
          hint="We'll never share your email"
          left={<TextInput.Icon icon="email" />}
        />
        <AppInput
          label="Password"
          value={password}
          onChangeText={setPassword}
          secureTextEntry
          left={<TextInput.Icon icon="lock" />}
        />
        <AppButton label="Validate" onPress={handleValidate} style={styles.mt8} />

        <AppDivider />

        {/* ── BUTTONS ─────────────────────────────────────── */}
        <SectionHeader label="Buttons" />
        <View style={styles.row}>
          <AppButton label="Contained" variant="contained" onPress={() => setSnackVisible(true)} />
          <AppButton label="Outlined"  variant="outlined"  onPress={() => {}} />
          <AppButton label="Text"      variant="text"      onPress={() => {}} />
        </View>
        <AppButton label="Full Width — Open Modal" fullWidth onPress={() => setModalVisible(true)} />

        <AppDivider />

        {/* ── CHECKBOXES ──────────────────────────────────── */}
        <SectionHeader label="Checkboxes" />
        <AppCheckbox
          label="Accept Terms & Conditions"
          checked={checkA}
          onToggle={() => setCheckA(!checkA)}
        />
        <AppCheckbox
          label="Subscribe to newsletter"
          checked={checkB}
          onToggle={() => setCheckB(!checkB)}
        />
        <AppCheckbox
          label="Disabled option"
          checked={false}
          onToggle={() => {}}
          disabled
        />

        <AppDivider />

        {/* ── DATE PICKERS ────────────────────────────────── */}
        <SectionHeader label="Date / Time Pickers" />
        <AppDatePicker
          label="Select Date"
          value={date}
          onChange={setDate}
          mode="date"
        />
        <AppDatePicker
          label="Select Time"
          value={date}
          onChange={setDate}
          mode="time"
        />

        <AppDivider />

        {/* ── CHIPS ───────────────────────────────────────── */}
        <SectionHeader label="Chip Group (Multi-select)" />
        <AppChipGroup
          chips={chips}
          selected={selectedChips}
          onSelect={toggleChip}
        />

        <AppDivider />

        {/* ── RADIO ───────────────────────────────────────── */}
        <SectionHeader label="Radio Group" />
        <AppRadioGroup
          label="Pick one"
          options={radioOptions}
          value={radio}
          onChange={setRadio}
          direction="row"
        />

        <AppDivider />

        {/* ── SELECT ──────────────────────────────────────── */}
        <SectionHeader label="Dropdown Select" />
        <AppSelect
          label="Favourite Fruit"
          options={fruitOptions}
          value={fruit}
          onChange={setFruit}
          placeholder="Choose a fruit..."
        />

        <AppDivider />

        {/* ── CARD ────────────────────────────────────────── */}
        <SectionHeader label="Card" />
        <AppCard
          title="React Native Paper"
          subtitle="Material Design 3 for RN"
          content="Build beautiful, accessible Android and iOS apps with a consistent set of components."
          onPress={() => setSnackVisible(true)}
          actions={
            <>
              <AppButton label="Learn" variant="text" onPress={() => {}} />
              <AppButton label="Get Started" variant="contained" onPress={() => setModalVisible(true)} />
            </>
          }
        />

        <AppDivider />

        {/* ── LIST ITEMS ──────────────────────────────────── */}
        <SectionHeader label="List Items" />
        <List.Section>
          {listItems.map((item) => (
            <AppListItem
              key={item.id}
              title={item.title}
              description={item.count + ' items'}
              leftIcon={item.icon}
              rightIcon="chevron-right"
              onPress={() => setSnackVisible(true)}
            />
          ))}
        </List.Section>

        <View style={styles.spacer} />
      </ScrollView>

      {/* ── MODAL ───────────────────────────────────────── */}
      <AppModal
        visible={modalVisible}
        onDismiss={() => setModalVisible(false)}
        title="Reusable Modal"
      >
        <Text variant="bodyMedium" style={{ marginBottom: 16, color: theme.colors.onSurface }}>
          Drop any content inside — forms, confirmations, custom layouts.
        </Text>
        <AppButton label="Close" onPress={() => setModalVisible(false)} />
      </AppModal>

      {/* ── SNACKBAR ────────────────────────────────────── */}
      <AppSnackbar
        visible={snackVisible}
        message="Action completed successfully!"
        onDismiss={() => setSnackVisible(false)}
        action={{ label: 'Undo', onPress: () => {} }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  scroll:    { padding: 16 },
  row:       { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 12 },
  mt8:       { marginTop: 8 },
  spacer:    { height: 40 },
  badgeWrap: { position: 'absolute', top: -4, right: -4 },
});