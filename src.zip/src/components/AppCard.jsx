// src/components/AppCard.jsx
import React from 'react';
import { StyleSheet } from 'react-native';
import { Card, Text, useTheme } from 'react-native-paper';

/**
 * AppCard
 * Props:
 *  - title       (string) required — card heading
 *  - subtitle    (string) smaller text under title
 *  - content     (string) body paragraph text
 *  - coverImage  (string) image URL for top cover photo
 *  - onPress     (func)   makes whole card pressable
 *  - actions     (node)   React elements for the actions row (e.g. buttons)
 *  - style       (object) extra card style
 *  - elevation   (number) 0–5 (default: 2)
 */
export function AppCard({
  title,
  subtitle,
  content,
  coverImage,
  onPress,
  actions,
  style,
  elevation = 2,
}) {
  const theme = useTheme();

  return (
    <Card
      style={[styles.card, { backgroundColor: theme.colors.surface }, style]}
      onPress={onPress}
      elevation={elevation}
    >
      {coverImage && <Card.Cover source={{ uri: coverImage }} />}
      <Card.Title
        title={title}
        subtitle={subtitle}
        titleStyle={{ color: theme.colors.onSurface }}
        subtitleStyle={{ color: theme.colors.onSurfaceVariant }}
      />
      {content && (
        <Card.Content>
          <Text variant="bodyMedium" style={{ color: theme.colors.onSurfaceVariant }}>
            {content}
          </Text>
        </Card.Content>
      )}
      {actions && <Card.Actions>{actions}</Card.Actions>}
    </Card>
  );
}

const styles = StyleSheet.create({
  card: {
    marginVertical: 8,
    borderRadius: 12,
  },
});