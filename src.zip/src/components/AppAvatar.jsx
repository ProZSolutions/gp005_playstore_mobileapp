// src/components/AppAvatar.jsx
import React from 'react';
import { StyleSheet, View } from 'react-native';
import { Avatar, Text, useTheme } from 'react-native-paper';

/**
 * AppAvatar — shows image, icon, or initials avatar
 * Props:
 *  - type    (string) 'image' | 'icon' | 'text'  (default: 'text')
 *  - source  (string) image URI — used when type='image'
 *  - icon    (string) MaterialCommunityIcon name — used when type='icon'
 *  - label   (string) 1–2 character initials — used when type='text'
 *  - size    (number) diameter in px (default: 48)
 *  - color   (string) background color override
 *  - style   (object) extra container style
 *
 * Examples:
 *  <AppAvatar type="image" source="https://example.com/photo.jpg" />
 *  <AppAvatar type="icon" icon="account" />
 *  <AppAvatar type="text" label="JD" />
 */
export function AppAvatar({ type = 'text', source, icon, label, size = 48, color, style }) {
  const theme = useTheme();
  const bg = color || theme.colors.primaryContainer;

  if (type === 'image' && source) {
    return <Avatar.Image size={size} source={{ uri: source }} style={style} />;
  }

  if (type === 'icon' && icon) {
    return (
      <Avatar.Icon
        size={size}
        icon={icon}
        style={[{ backgroundColor: bg }, style]}
        color={theme.colors.onPrimaryContainer}
      />
    );
  }

  return (
    <Avatar.Text
      size={size}
      label={label ?? '?'}
      style={[{ backgroundColor: bg }, style]}
      color={theme.colors.onPrimaryContainer}
    />
  );
}