// src/components/AppModal.jsx
import React from 'react';
import { StyleSheet } from 'react-native';
import { Modal, Portal, Text, useTheme } from 'react-native-paper';

/**
 * AppModal
 * Props:
 *  - visible      (bool)   required — controls show/hide
 *  - onDismiss    (func)   required — called when backdrop is tapped
 *  - title        (string) optional heading inside modal
 *  - children     (node)   modal body content
 *  - style        (object) override container style
 *  - dismissable  (bool)   allow backdrop tap to close (default: true)
 *
 * NOTE: PaperProvider already includes Portal.Host,
 *       so AppModal works without any extra setup.
 *
 * Example:
 *  <AppModal visible={show} onDismiss={() => setShow(false)} title="Confirm Delete">
 *    <Text>Are you sure?</Text>
 *    <AppButton label="Yes" onPress={handleDelete} />
 *  </AppModal>
 */
export function AppModal({
  visible,
  onDismiss,
  title,
  children,
  style,
  dismissable = true,
}) {
  const theme = useTheme();

  return (
    <Portal>
      <Modal
        visible={visible}
        onDismiss={dismissable ? onDismiss : undefined}
        contentContainerStyle={[
          styles.container,
          {
            backgroundColor: theme.colors.surface,
            borderRadius: theme.roundness * 2,
          },
          style,
        ]}
      >
        {title && (
          <Text
            variant="titleLarge"
            style={[styles.title, { color: theme.colors.onSurface }]}
          >
            {title}
          </Text>
        )}
        {children}
      </Modal>
    </Portal>
  );
}

const styles = StyleSheet.create({
  container: {
    margin: 20,
    padding: 24,
  },
  title: {
    marginBottom: 16,
    fontWeight: '700',
  },
});