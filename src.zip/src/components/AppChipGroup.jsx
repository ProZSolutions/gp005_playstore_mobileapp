// src/components/AppChipGroup.jsx
import React from 'react';
import { StyleSheet, View, ScrollView } from 'react-native';
import { Chip } from 'react-native-paper';

/**
 * AppChipGroup
 * Props:
 *  - chips      (array) required — [{ id, label, icon? }]
 *  - selected   (array) array of selected ids e.g. ['ts', 'react']
 *  - onSelect   (func)  called with (id) when a chip is tapped
 *  - mode       (string) 'flat' | 'outlined' (default: 'outlined')
 *  - scrollable (bool)  horizontal ScrollView (default: true)
 *  - style      (object) outer container style
 *
 * Example:
 *  const chips = [
 *    { id: 'react', label: 'React Native', icon: 'react' },
 *    { id: 'ts',    label: 'TypeScript' },
 *  ];
 *  const [selected, setSelected] = useState([]);
 *  const toggle = (id) =>
 *    setSelected(prev => prev.includes(id) ? prev.filter(c => c !== id) : [...prev, id]);
 *
 *  <AppChipGroup chips={chips} selected={selected} onSelect={toggle} />
 */
export function AppChipGroup({
  chips,
  selected = [],
  onSelect,
  mode = 'outlined',
  scrollable = true,
  style,
}) {
  if (scrollable) {
    return (
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={[styles.row, style]}
        contentContainerStyle={styles.rowContent}
      >
        {chips.map((chip) => (
          <Chip
            key={chip.id}
            mode={mode}
            icon={chip.icon}
            selected={selected.includes(chip.id)}
            onPress={() => onSelect && onSelect(chip.id)}
            style={styles.chip}
          >
            {chip.label}
          </Chip>
        ))}
      </ScrollView>
    );
  }

  return (
    <View style={[styles.wrap, style]}>
      {chips.map((chip) => (
        <Chip
          key={chip.id}
          mode={mode}
          icon={chip.icon}
          selected={selected.includes(chip.id)}
          onPress={() => onSelect && onSelect(chip.id)}
          style={styles.chip}
        >
          {chip.label}
        </Chip>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  row: { paddingVertical: 4 },
  rowContent: { flexDirection: 'row', alignItems: 'center' },
  wrap: { flexDirection: 'row', flexWrap: 'wrap', paddingVertical: 4 },
  chip: { marginRight: 8, marginBottom: 8 },
});