// src/components/AppInput.jsx
import React from 'react';
import { StyleSheet, View } from 'react-native';
import { TextInput, HelperText } from 'react-native-paper';

/**
 * AppInput
 * Props:
 *  - label           (string) required
 *  - value           (string)
 *  - onChangeText    (func)
 *  - error           (string) shows red helper text below
 *  - hint            (string) shows blue helper text below
 *  - containerStyle  (object) wrapping View style
 *  - style           (object) TextInput style
 *  - ...rest         any other TextInput / react-native-paper TextInput props
 *                    e.g. keyboardType, secureTextEntry, left, right, multiline
 */
export function AppInput({
  label,
  error,
  hint,
  containerStyle,
  style,
  ...rest
}) {
  return (
    <View style={[styles.container, containerStyle]}>
      <TextInput
        label={label}
        mode="outlined"
        error={!!error}
        style={[styles.input, style]}
        {...rest}
      />
      {error ? (
        <HelperText type="error" visible={!!error}>
          {error}
        </HelperText>
      ) : hint ? (
        <HelperText type="info" visible={!!hint}>
          {hint}
        </HelperText>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { marginVertical: 6 },
  input: { backgroundColor: 'transparent' },
});