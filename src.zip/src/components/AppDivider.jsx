// src/components/AppDivider.jsx
import React from 'react';
import { StyleSheet, View } from 'react-native';
import { Divider, Text, useTheme } from 'react-native-paper';

/**
 * AppDivider — horizontal line separator with optional label
 * Props:
 *  - label  (string) optional text centered in the divider
 *  - style  (object) container style override
 *
 * Example:
 *  <AppDivider />
 *  <AppDivider label="OR" />
 */
export function AppDivider({ label, style }) {
  const theme = useTheme();

  if (!label) {
    return <Divider style={[styles.plain, style]} />;
  }

  return (
    <View style={[styles.row, style]}>
      <Divider style={styles.line} />
      <Text
        variant="labelMedium"
        style={[styles.text, { color: theme.colors.onSurfaceVariant }]}
      >
        {label}
      </Text>
      <Divider style={styles.line} />
    </View>
  );
}

const styles = StyleSheet.create({
  plain: { marginVertical: 16 },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 16,
  },
  line: { flex: 1 },
  text: { marginHorizontal: 12 },
});