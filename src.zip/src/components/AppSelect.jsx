// src/components/AppSelect.jsx
import React, { useState } from 'react';
import { StyleSheet, View, ScrollView } from 'react-native';
import { Menu, TextInput, HelperText, Divider } from 'react-native-paper';

/**
 * AppSelect — Dropdown / Select Menu
 * Props:
 *  - label         (string) required — floating label
 *  - options       (array)  required — [{ label, value }]
 *  - value         (string|number) currently selected value
 *  - onChange      (func)   called with (value) when user picks
 *  - error         (string) shows red helper text
 *  - placeholder   (string) shown when nothing is selected
 *  - disabled      (bool)   blocks interaction
 *  - containerStyle (object) wrapping View style
 *
 * Example:
 *  const options = [
 *    { label: 'Apple',  value: 'apple' },
 *    { label: 'Banana', value: 'banana' },
 *  ];
 *  <AppSelect label="Fruit" options={options} value={selected} onChange={setSelected} />
 */
export function AppSelect({
  label,
  options,
  value,
  onChange,
  error,
  placeholder = 'Select an option',
  disabled = false,
  containerStyle,
}) {
  const [visible, setVisible] = useState(false);

  const selectedLabel = options.find((o) => o.value === value)?.label ?? '';

  return (
    <View style={[styles.container, containerStyle]}>
      <Menu
        visible={visible}
        onDismiss={() => setVisible(false)}
        anchor={
          <TextInput
            label={label}
            mode="outlined"
            value={selectedLabel}
            placeholder={placeholder}
            editable={false}
            disabled={disabled}
            error={!!error}
            right={
              <TextInput.Icon
                icon={visible ? 'chevron-up' : 'chevron-down'}
                onPress={() => !disabled && setVisible(true)}
              />
            }
            onPressIn={() => !disabled && setVisible(true)}
            style={styles.input}
          />
        }
      >
        <ScrollView style={{ maxHeight: 250 }}>
          {options.map((opt, i) => (
            <React.Fragment key={String(opt.value)}>
              <Menu.Item
                title={opt.label}
                onPress={() => {
                  onChange(opt.value);
                  setVisible(false);
                }}
              />
              {i < options.length - 1 && <Divider />}
            </React.Fragment>
          ))}
        </ScrollView>
      </Menu>
      {error && (
        <HelperText type="error" visible={!!error}>
          {error}
        </HelperText>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { marginVertical: 6 },
  input: { backgroundColor: 'transparent' },
});