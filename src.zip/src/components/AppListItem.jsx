// src/components/AppListItem.jsx
import React from 'react';
import { List, Divider } from 'react-native-paper';

/**
 * AppListItem
 * Props:
 *  - title         (string) required — primary text
 *  - description   (string) secondary/subtitle text
 *  - leftIcon      (string) MaterialCommunityIcon name e.g. 'inbox'
 *  - rightIcon     (string) MaterialCommunityIcon name e.g. 'chevron-right'
 *  - onPress       (func)   tap handler
 *  - showDivider   (bool)   show a line below item (default: true)
 *  - titleStyle    (object) override title text style
 *  - descriptionStyle (object) override description text style
 */
export function AppListItem({
  title,
  description,
  leftIcon,
  rightIcon,
  onPress,
  showDivider = true,
  titleStyle,
  descriptionStyle,
}) {
  return (
    <>
      <List.Item
        title={title}
        description={description}
        left={leftIcon ? (props) => <List.Icon {...props} icon={leftIcon} /> : undefined}
        right={rightIcon ? (props) => <List.Icon {...props} icon={rightIcon} /> : undefined}
        onPress={onPress}
        titleStyle={titleStyle}
        descriptionStyle={descriptionStyle}
      />
      {showDivider && <Divider />}
    </>
  );
}