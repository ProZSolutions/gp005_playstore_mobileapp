// src/components/AppRadioGroup.jsx
import React from 'react';
import { StyleSheet, View } from 'react-native';
import { RadioButton, Text, useTheme } from 'react-native-paper';

/**
 * AppRadioGroup
 * Props:
 *  - label          (string) optional heading above the group
 *  - options        (array)  required — [{ label, value, disabled? }]
 *  - value          (string) currently selected value
 *  - onChange       (func)   called with (value) on selection
 *  - direction      (string) 'row' | 'column' (default: 'column')
 *  - containerStyle (object) wrapping View style
 *
 * Example:
 *  const options = [
 *    { label: 'Male',   value: 'male' },
 *    { label: 'Female', value: 'female' },
 *    { label: 'Other',  value: 'other', disabled: true },
 *  ];
 *  <AppRadioGroup label="Gender" options={options} value={radio} onChange={setRadio} />
 */
export function AppRadioGroup({
  label,
  options,
  value,
  onChange,
  direction = 'column',
  containerStyle,
}) {
  const theme = useTheme();

  return (
    <View style={[styles.container, containerStyle]}>
      {label && (
        <Text
          variant="labelLarge"
          style={{ color: theme.colors.onSurfaceVariant, marginBottom: 8 }}
        >
          {label}
        </Text>
      )}
      <RadioButton.Group onValueChange={onChange} value={value}>
        <View style={{ flexDirection: direction, flexWrap: 'wrap' }}>
          {options.map((opt) => (
            <View key={opt.value} style={styles.option}>
              <RadioButton.Android
                value={opt.value}
                disabled={opt.disabled}
                color={theme.colors.primary}
              />
              <Text
                onPress={() => !opt.disabled && onChange(opt.value)}
                style={{
                  color: opt.disabled
                    ? theme.colors.onSurfaceDisabled
                    : theme.colors.onSurface,
                }}
              >
                {opt.label}
              </Text>
            </View>
          ))}
        </View>
      </RadioButton.Group>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { marginVertical: 6 },
  option: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 16,
    marginBottom: 8,
  },
});