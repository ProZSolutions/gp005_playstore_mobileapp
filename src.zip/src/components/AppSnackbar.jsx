// src/components/AppSnackbar.jsx
import React from 'react';
import { Snackbar } from 'react-native-paper';

/**
 * AppSnackbar — Toast-style notification at bottom of screen
 * Props:
 *  - visible    (bool)   required — controls show/hide
 *  - message    (string) required — text to display
 *  - onDismiss  (func)   required — called when auto-dismissed or swiped
 *  - duration   (number) ms before auto-dismiss (default: 3000)
 *  - action     (object) { label: string, onPress: func } — optional action button
 *
 * Example:
 *  <AppSnackbar
 *    visible={snackVisible}
 *    message="Saved successfully!"
 *    onDismiss={() => setSnackVisible(false)}
 *    action={{ label: 'Undo', onPress: handleUndo }}
 *  />
 */
export function AppSnackbar({
  visible,
  message,
  onDismiss,
  duration = 3000,
  action,
}) {
  return (
    <Snackbar
      visible={visible}
      onDismiss={onDismiss}
      duration={duration}
      action={action}
    >
      {message}
    </Snackbar>
  );
}