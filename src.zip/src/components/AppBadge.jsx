// src/components/AppBadge.jsx
import React from 'react';
import { Badge } from 'react-native-paper';

/**
 * AppBadge
 * Props:
 *  - count   (number) numeric value — displays '99+' if over 99
 *  - label   (string) custom text (overrides count)
 *  - visible (bool)   show or hide badge (default: true)
 *  - size    (number) badge diameter in px (default: 20)
 *  - style   (object) extra style overrides
 */
export function AppBadge({ count, label, visible = true, size = 20, style }) {
  const display = label ?? (count !== undefined ? String(count > 99 ? '99+' : count) : '');

  return (
    <Badge visible={visible} size={size} style={style}>
      {display}
    </Badge>
  );
}