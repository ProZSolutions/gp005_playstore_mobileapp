// src/components/AppButton.jsx
import React from 'react';
import { StyleSheet } from 'react-native';
import { Button } from 'react-native-paper';

/**
 * AppButton
 * Props:
 *  - label       (string)  required — button text
 *  - variant     (string)  'contained' | 'outlined' | 'text'  (default: 'contained')
 *  - fullWidth   (bool)    stretch to parent width
 *  - onPress     (func)    tap handler
 *  - disabled    (bool)
 *  - loading     (bool)    shows spinner
 *  - icon        (string)  MaterialCommunityIcon name e.g. 'check'
 *  - style       (object)  extra style overrides
 */
export function AppButton({
  label,
  variant = 'contained',
  fullWidth = false,
  style,
  ...rest
}) {
  return (
    <Button
      mode={variant}
      style={[fullWidth && styles.fullWidth, style]}
      contentStyle={styles.content}
      {...rest}
    >
      {label}
    </Button>
  );
}

const styles = StyleSheet.create({
  fullWidth: { width: '100%' },
  content: { paddingVertical: 4 },
});