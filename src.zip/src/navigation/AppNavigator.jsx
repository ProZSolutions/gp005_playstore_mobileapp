// src/navigation/AppNavigator.jsx
import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { DemoScreen } from '../screens/DemoScreen';

const Stack = createNativeStackNavigator();

export function AppNavigator({ toggleTheme, isDark }) {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen
        name="Demo"
        component={DemoScreen}
        initialParams={{ toggleTheme, isDark }}
      />
    </Stack.Navigator>
  );
}