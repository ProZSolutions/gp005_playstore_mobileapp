// src/components/AppDatePicker.jsx
// Requires: npm install react-native-date-picker
import React, { useState } from 'react';
import { StyleSheet, View } from 'react-native';
import { TextInput, HelperText, useTheme } from 'react-native-paper';
import DatePicker from 'react-native-date-picker';

/**
 * AppDatePicker
 * Props:
 *  - label         (string) required — floating label
 *  - value         (Date|undefined) currently selected date
 *  - onChange      (func)  called with (Date) when user confirms
 *  - mode          (string) 'date' | 'time' | 'datetime'  (default: 'date')
 *  - minimumDate   (Date)  optional lower bound
 *  - maximumDate   (Date)  optional upper bound
 *  - error         (string) shows red helper text
 *  - placeholder   (string) text when no date selected
 *  - containerStyle (object) wrapping View style
 */
export function AppDatePicker({
  label,
  value,
  onChange,
  mode = 'date',
  minimumDate,
  maximumDate,
  error,
  placeholder = 'Select date',
  containerStyle,
}) {
  const [open, setOpen] = useState(false);
  const theme = useTheme();

  const formatDate = (date) => {
    if (!date) return '';
    if (mode === 'date') return date.toLocaleDateString();
    if (mode === 'time') return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    return date.toLocaleString();
  };

  return (
    <View style={[styles.container, containerStyle]}>
      <TextInput
        label={label}
        mode="outlined"
        value={formatDate(value)}
        placeholder={placeholder}
        error={!!error}
        editable={false}
        right={
          <TextInput.Icon
            icon={mode === 'time' ? 'clock-outline' : 'calendar'}
            onPress={() => setOpen(true)}
            color={theme.colors.primary}
          />
        }
        onPressIn={() => setOpen(true)}
        style={styles.input}
      />
      {error && (
        <HelperText type="error" visible={!!error}>
          {error}
        </HelperText>
      )}
      <DatePicker
        modal
        open={open}
        date={value || new Date()}
        mode={mode}
        minimumDate={minimumDate}
        maximumDate={maximumDate}
        onConfirm={(date) => {
          setOpen(false);
          onChange(date);
        }}
        onCancel={() => setOpen(false)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { marginVertical: 6 },
  input: { backgroundColor: 'transparent' },
});